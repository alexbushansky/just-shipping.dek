<?php

return [
    'settings'=>'Настройки',
    'all_cars_types'=>'Типы грузовиков',
    'id'=>'Id',
    'action'=>'Действия',
    'name'=>'Тип транспорта',
    'all_city'=>'Города',
    'all_region'=>'Регионы',
    'all_country'=>'Страны',
    'edit'=>'Редактировать',

];
