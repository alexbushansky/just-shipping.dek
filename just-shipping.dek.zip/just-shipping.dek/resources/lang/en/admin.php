<?php

return [
    'settings'=>'Settings',
    'all_cars_types'=>'Types of ',
    'id'=>'id',
    'action'=>'Action',
    'name'=>'Type of Transport',
    'all_city'=>'City',
    'all_region'=>'Region',
    'all_country'=>'Country',
    'edit'=>'Edit',

];
