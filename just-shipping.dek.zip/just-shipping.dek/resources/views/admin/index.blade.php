@extends('admin.devApp')

@section('title','Dashboard')

@section('content')

Content



@endsection




