ссылка <a href="{{route('dialogs.show',['dialog'=>$model->id])}}">Перейти</a>
