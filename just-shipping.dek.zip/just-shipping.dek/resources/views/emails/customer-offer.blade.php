
hello from customer-offer
ваш заказ принят
Чтобы посмотреть заказ перейдите по адресу <a href="{{route('customer-offers.show',['id'=>$offer->id])}}">{{$offer->title}}</a>

