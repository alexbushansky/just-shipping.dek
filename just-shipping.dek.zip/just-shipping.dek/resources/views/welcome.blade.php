@extends('layouts.menu')

@section('content')


    <div class="content">
        <div class="title m-b-md">
            <h3>Добро пожаловать</h3>
        </div>


    </div>

@endsection

