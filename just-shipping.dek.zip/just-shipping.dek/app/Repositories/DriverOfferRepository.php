<?php


namespace App\Repositories;



use App\Models\DriverOffer;
use App\Repositories\Interfaces\DriverOfferRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class DriverOfferRepository implements DriverOfferRepositoryInterface
{

    protected $driverOffer;
    private const ACTIVE_ORDER = 1;
    private const ACCEPTED_OFFER = 2;

    public function __construct(DriverOffer $driverOffer)
    {
        $this->driverOffer = $driverOffer;
    }



    public function filterDriverOffers($title, $country_id ,$region_id, $city_id,$weight,$capacity,$type): LengthAwarePaginator
    {

        $weight=(int)$weight;
        $capacity = (int)$capacity;

        return $this->driverOffer::with('country','region','city','types')
            ->where('status_id','=',self::ACTIVE_ORDER)
            ->when($country_id,function ($query,$country_id) {
                return $query->where('country_id','=',$country_id);
            })
            ->when($region_id,function ($query,$region_id) {
                return $query->where('region_id','=',$region_id);
            })->when($city_id,function ($query,$city_id) {
                return $query->where('city_id','=',$city_id);
            })->when($title,function ($query,$title) {
                return $query->where('title','LIKE','%'.$title.'%');
            })->when($weight,function ($query,$weight)
            {
                return $query->where('weight','>=',$weight);
            })->when($capacity,function ($query,$capacity)
            {
                return $query->where('capacity','>=',$capacity);
            })->when($type,function ($query,$type)
            {
                return $query->whereHas('types',function ($query) use ($type)
                {
                    $query->where('type_id',$type);
                });
            })
            ->orderBy('created_at','DESC')
            ->leftJoin('driver_cars','driver_car_id','=','driver_cars.car_id')
            ->with('carType')
            ->paginate(9)
            ->appends(request()->query());
    }

    public function acceptedOffer($driverOfferId)
    {

        $this->driverOffer = $this->driverOffer->find($driverOfferId);
        $this->driverOffer->status_id = self::ACCEPTED_OFFER;
        $this->driverOffer->save();
    }
}
