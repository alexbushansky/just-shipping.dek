<?php


namespace App\Repositories;


use App\Repositories\Interfaces\DialogRepositoryInterface;

class DialogRepository implements DialogRepositoryInterface
{

    public function changeStatus($id)
    {
        // TODO: Implement changeStatus() method.
    }
}
