<?php


namespace App\Repositories\Interfaces;


interface DialogRepositoryInterface
{
    public function changeStatus($id);
}
