<?php


namespace App\Services\Interfaces;


interface DriverOfferServiceInterface
{
    public function changeStatus($id);
}
