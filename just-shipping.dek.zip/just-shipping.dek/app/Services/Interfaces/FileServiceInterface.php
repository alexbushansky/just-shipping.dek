<?php


namespace App\Services\Interfaces;


interface FileServiceInterface
{
    public function makeCarPhoto($file);
    public function makeOfferPhoto($file);
}
